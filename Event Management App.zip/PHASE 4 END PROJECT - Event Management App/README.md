This folder contains the files of the project.
Note: .angular, node_modules files are not added taking into account the size of these files.

The full project is present in my repository: https://github.com/AkshayTR2023/Event-Management-App.git