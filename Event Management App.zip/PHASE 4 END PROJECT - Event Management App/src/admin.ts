//-------------------------github.com/AkshayTR2023--------------------------//
export class Admin {
  id!:number;
  email!: string;
  password!: string;
  loggedIn!: boolean;
}
//-------------------------github.com/AkshayTR2023--------------------------//