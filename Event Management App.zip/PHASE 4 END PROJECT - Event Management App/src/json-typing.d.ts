declare var $: any;
declare var stripe: any;
declare var elements: any;