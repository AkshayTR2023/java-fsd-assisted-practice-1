/*********************************************SOURCE CODE******************************************************/
/*********************KthSmallestMain.java********************************************************************/
package com.array.smallest;

import java.util.Scanner;

class KthSmallestFinder 
{ 
	public static int kth(int arr[], int l, int r, int k) 
    	{ 
             		if (k > 0 && k <= r - l + 1) 
        		{ 
            			int pos = randomPartition(arr, l, r); 
            			if (pos-l == k-1) 
                			return arr[pos]; 
            			if (pos-l > k-1) 
                			return kth(arr, l, pos-1, k); 
            			return kth(arr, pos+1, r, k-pos+l-1); 
        		} 
        return Integer.MAX_VALUE; 
    } 
    static void swap(int arr[], int i, int j) 
    { 
        int temp = arr[i]; 
        arr[i] = arr[j]; 
        arr[j] = temp; 
    } 
    static int partition(int arr[], int l, int r) 
    { 
        int x = arr[r], i = l; 
        for (int j = l; j <= r - 1; j++) 
        { 
            if (arr[j] <= x) 
            { 
                swap(arr, i, j); 
                i++; 
            } 
        } 
        swap(arr, i, r); 
        return i; 
    } 
    static int randomPartition(int arr[], int l, int r) 
    { 
        int n = r-l+1; 
        int pivot = (int)(Math.random()) * (n-1); 
        swap(arr, l + pivot, r); 
        return partition(arr, l, r); 
    } 
}  
public class KthSmallestMain
{
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
        System.out.print("Enter the number of array elements: ");
        int n=sc.nextInt();
        int[] arr= new int[n];
        System.out.println("Enter the unsorted array elements");
        for(int i=0;i<n;i++)
        	arr[i]=sc.nextInt(); 
        System.out.println("4th smallest element is "+ KthSmallestFinder.kth(arr, 0, n-1, 4)); 
        sc.close();
    }
}
