package com.circ.linkedlist;
class Node {
    int data;
    Node next;

    public Node(int data) {
        this.data = data;
        this.next = null;
    }
}

class CircularLinkedList {
    Node head;

    public void insert(int data) {
        Node newNode = new Node(data);

        // If the list is empty, make the new node as the head
        if (head == null) {
            head = newNode;
            head.next = head; // Point to itself to make it circular
            return;
        }

        // If the new node's data is smaller than the head's data
        if (data < head.data) {
            newNode.next = head;
            Node currNode = head;
            while (currNode.next != head) {
                currNode = currNode.next;
            }
            currNode.next = newNode;
            head = newNode;
            return;
        }

        Node currNode = head;
        while (currNode.next != head && currNode.next.data < data) {
            currNode = currNode.next;
        }

        newNode.next = currNode.next;
        currNode.next = newNode;
    }

    public void printList() {
        if (head == null) {
            System.out.println("Circular Linked List is empty.");
            return;
        }

        Node currNode = head;
        do {
            System.out.print(currNode.data + " ");
            currNode = currNode.next;
        } while (currNode != head);
        System.out.println();
    }
}

public class CircLinkedListMain {
    public static void main(String[] args) {
        CircularLinkedList circularLinkedList = new CircularLinkedList();
        circularLinkedList.insert(2);
        circularLinkedList.insert(4);
        circularLinkedList.insert(6);
        circularLinkedList.insert(8);

        System.out.println("Circular Linked List after insertion:");
        circularLinkedList.printList();
    }
}
