/***************************SOURCE CODE*****************************************/
/***********************DoublyLinkedListMain.java*******************************/
package com.doubly.linkedlist;

class Node {
    int data;
    Node prev;
    Node next;

    public Node(int data) {
        this.data = data;
        this.prev = null;
        this.next = null;
    }
}

class DoublyLinkedList {
    Node head;

    public void insert(int data) {
        Node newNode = new Node(data);

        if (head == null) {
            head = newNode;
            return;
        }

        Node currNode = head;
        while (currNode.next != null) {
            currNode = currNode.next;
        }

        currNode.next = newNode;
        newNode.prev = currNode;
    }

    public void printListForward() {
        if (head == null) {
            System.out.println("Doubly Linked List is empty.");
            return;
        }

        Node currNode = head;
        System.out.print("Doubly Linked List (forward): ");
        while (currNode != null) {
            System.out.print(currNode.data + " ");
            currNode = currNode.next;
        }
        System.out.println();
    }

    public void printListBackward() {
        if (head == null) {
            System.out.println("Doubly Linked List is empty.");
            return;
        }

        Node currNode = head;
        while (currNode.next != null) {
            currNode = currNode.next;
        }

        System.out.print("Doubly Linked List (backward): ");
        while (currNode != null) {
            System.out.print(currNode.data + " ");
            currNode = currNode.prev;
        }
        System.out.println();
    }
}

public class DoublyLinkedListMain {
    public static void main(String[] args) {
        DoublyLinkedList doublyLinkedList = new DoublyLinkedList();
        doublyLinkedList.insert(1);
        doublyLinkedList.insert(2);
        doublyLinkedList.insert(3);
        doublyLinkedList.insert(4);
        doublyLinkedList.insert(5);

        doublyLinkedList.printListForward();
        doublyLinkedList.printListBackward();
    }
}

