package com.array.rotate;
import java.util.Scanner;

class RotateArray { 
	public static void rotate(int[] nums, int k) {
    	if(k > nums.length) 
       			k=k%nums.length;
 		int[] result = new int[nums.length];
 		for(int i=0; i < k; i++){
        		result[i] = nums[nums.length-k+i];
 		}
 		int j=0;
    		for(int i=k; i<nums.length; i++){
        			result[i] = nums[j];
        			j++;
    		}
 		System.arraycopy( result, 0, nums, 0, nums.length );
	}
} 
public class RotArrayMain
{
	public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        System.out.print("Enter the number of array elements: ");
        int n=sc.nextInt();
        int[] arr= new int[n];
        System.out.println("Enter the array elements");
        for(int i=0;i<n;i++)
        	arr[i]=sc.nextInt();
        //calling method to rotate the array elements.
        RotateArray.rotate(arr, 5);
        System.out.println("The rotated array is...");
        for(int x:arr){
            	System.out.print(x+" ");
        	}
        sc.close();
	}
}

