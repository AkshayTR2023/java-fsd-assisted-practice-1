/***********************************SOURCE CODE**********************************/
/*********************KthSmallestMain.java************************************/

package com.array.rangequery;
import java.util.Scanner;
public class RangeQueryMain{
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        
        System.out.print("Enter the number of elements: ");
        int n = sc.nextInt();
        
        // Create an array to store the elements
        int[] elements = new int[n];
        
        // Read the elements from the user
        System.out.println("Enter the elements:");
        for (int i = 0; i < n; i++) {
            elements[i] = sc.nextInt();
        }
        
        System.out.print("Enter the range (L and R): ");
        int L = sc.nextInt();
        int R = sc.nextInt();
        sc.close();
        // Validate the range
        if (L < 0 || R >= n || L > R) {
            System.out.println("Invalid range!");
            return;
            
        }
        
        // Calculate the sum of elements in the range
        int sum = 0;
        for (int i = L; i <= R; i++) {
            sum += elements[i];
        }
        
        System.out.println("Sum of elements in the range (" + L + ", " + R + "): " + sum);
        
    }
}

