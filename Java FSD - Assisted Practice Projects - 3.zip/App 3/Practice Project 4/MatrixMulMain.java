/*********************************************SOURCE CODE******************************************************/
/**************************************MatrixMulMain.java************************/
package com.matrix.mul;

import java.util.Scanner;
class Oper{
	static void fillMatrix(int[][] arr, int r, int c)
	{
		Scanner sc=new Scanner(System.in);
		for(int i=0;i<r;i++) {
			for(int j=0;j<c;j++)
				arr[i][j]=sc.nextInt();
		}
		
	}
	static void findProd(int[][]c, int[][]a, int[][]b, int rA, int cA, int rB, int cB)
	{
		for(int i=0;i<rA;i++) {
			for(int k=0;k<cB;k++) {
				int sum=0;
				for(int j=0;j<cA;j++) {
					sum+=a[i][j]*b[j][k];
				}
				c[i][k]=sum;
			}
		}
	}
	static void printMatrix(int[][] arr, int r, int c)
	{
		for(int i=0;i<r;i++) {
			for(int j=0;j<c;j++)
				System.out.print(arr[i][j]+" ");
			System.out.println();
		}
	}
	
}
public class MatrixMulMain {
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the dimensions of matrix A:");
			System.out.print("rows: ");
			int rowA=sc.nextInt();
			System.out.print("columns: ");
			int colA=sc.nextInt();
		System.out.println("Enter the dimensions of matrix B:");
			System.out.print("rows: ");
			int rowB=sc.nextInt();
			System.out.print("columns: ");
			int colB=sc.nextInt();
		if(colA!=rowB) {
			System.out.println("Multiplication can't be performed!");
			return;
		}
		int[][] a= new int[rowA][colA];
		int[][] b= new int[rowB][colB];
		System.out.println("Enter the elements of matrix A");
		Oper.fillMatrix(a, rowA, colA);
		System.out.println("Enter the elements of matrix B"); 
		Oper.fillMatrix(b, rowB, colB);
		int[][] c = new int[rowA][colB];
		Oper.findProd(c, a, b, rowA, colA, rowB, colB);
		System.out.println("The product of A and B is: ");
		Oper.printMatrix(c, rowA, colB);
		sc.close();
		
	}   
}
