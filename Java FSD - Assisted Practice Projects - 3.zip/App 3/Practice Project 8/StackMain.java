package com.stack;

import java.util.Stack;

public class StackMain {
    public static void main(String[] args) {
        Stack<Integer> stack = new Stack<>();

        // Insert elements into the stack
        stack.push(10);
        stack.push(20);
        stack.push(30);
        stack.push(40);
        stack.push(50);

        System.out.println("Stack after inserting elements: " + stack);

        // Remove elements from the stack
        int removedElement = stack.pop();
        System.out.println("Removed element: " + removedElement);
        System.out.println("Stack after removing an element: " + stack);

        // Peek the top element in the stack
        int topElement = stack.peek();
        System.out.println("Top element in the stack: " + topElement);

        // Check if the stack is empty
        boolean isEmpty = stack.empty();
        System.out.println("Is the stack empty? " + isEmpty);
    }
}
