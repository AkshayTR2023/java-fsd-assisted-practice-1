/*********************************************SOURCE CODE******************************************************/
/***********************************LinkedListMain.java**************************************************/
package com.linkedlist;

class Node {
    int data;
    Node next;

    public Node(int data) {
        this.data = data;
        this.next = null;
    }
}

class LinkedList {
    Node head;

    public void deleteKey(int key) {
        Node currNode = head;
        Node prevNode = null;

        // If the key is present at the head node
        if (currNode != null && currNode.data == key) {
            head = currNode.next; // Change the head
            return;
        }

        // Search for the key to be deleted, keeping track of the previous node
        while (currNode != null && currNode.data != key) {
            prevNode = currNode;
            currNode = currNode.next;
        }

        // If the key was not found in the list
        if (currNode == null) {
            return;
        }

        // Unlink the node from the linked list
        prevNode.next = currNode.next;
    }

    public void printList() {
        Node currNode = head;

        System.out.print("LinkedList: ");

        while (currNode != null) {
            System.out.print(currNode.data + " ");
            currNode = currNode.next;
        }
        System.out.println();
    }
}

public class LinkedListMain {
    public static void main(String[] args) {
        LinkedList linkedList = new LinkedList();
        linkedList.head = new Node(1);
        linkedList.head.next = new Node(2);
        linkedList.head.next.next = new Node(3);
        linkedList.head.next.next.next = new Node(4);
        linkedList.head.next.next.next.next = new Node(5);

        System.out.println("Before deletion:");
        linkedList.printList();

        int keyToDelete = 3;
        linkedList.deleteKey(keyToDelete);

        System.out.println("After deleting " + keyToDelete + ":");
        linkedList.printList();
    }
}

