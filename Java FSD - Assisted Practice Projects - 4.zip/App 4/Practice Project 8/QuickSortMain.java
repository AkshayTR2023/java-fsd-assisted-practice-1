package app4;

public class QuickSortMain {
	public static void main(String[] args) {
		int[] arr = {1,324,342,5,2,123,4,-12};
		System.out.println("The predefined array is:");
		for(int x: arr) System.out.print(x+ " ");
		
		System.out.println("\nPerforming Quick Sort...\nThe sorted array is:");
		sort(arr, 0, arr.length-1);
		for(int x: arr) System.out.print(x+ " ");
	}
	public static int partition(int arr[], int low, int high)
    {
        int pivot = arr[high];
        int i = (low-1); // index of smaller element
        for (int j=low; j<high; j++)
        { 
            if (arr[j] <= pivot)
            {
                i++;

                // swap arr[i] and arr[j]
                int temp = arr[i];
                arr[i] = arr[j];
                arr[j] = temp;
            }
        }

        // swap arr[i+1] and arr[high] (or pivot)
        int temp = arr[i+1];
        arr[i+1] = arr[high];
        arr[high] = temp;

        return i+1;
    }



    public static void sort(int arr[], int low, int high)
    {
        if (low < high)
        {

            int pi = partition(arr, low, high);

            
            sort(arr, low, pi-1);
            sort(arr, pi+1, high);
        }
    }

}
