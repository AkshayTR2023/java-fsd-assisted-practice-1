package app4;

public class InsertionSortMain {
	public static void main(String[] args) {
		int[] arr = {1,324,342,5,2,123,4,-12};
		System.out.println("The predefined array is:");
		for(int x: arr) System.out.print(x+ " ");
		
		System.out.println("\nPerforming Insertion Sort...\nThe sorted array is:");
		insertionSort(arr);
		for(int x: arr) System.out.print(x+ " ");
	}
	public static void insertionSort (int A[ ]) {
		int n=A.length;
	    for( int i = 0 ;i < n ; i++ ) {
	      int temp = A[ i ];    
	      int j = i;
	      while(  j > 0  && temp < A[ j -1]) {
	                A[ j ] = A[ j-1];   
	                j= j - 1;
	           }
	           A[ j ] = temp;       
	     }  
	}
}
