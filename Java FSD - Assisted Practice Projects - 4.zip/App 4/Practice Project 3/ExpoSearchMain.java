package app4;


import java.util.Scanner;

public class ExpoSearchMain {
    public static void main(String[] args) {
    	int[] arr= {-5,4,5,23,45,80,100,124};
		System.out.println("The predefined sorted array is: ");
		for(int x: arr) System.out.print(x+" ");
		System.out.println();
		Scanner sc = new Scanner(System.in);
		System.out.print("Enter the key to be found: ");
		int key =sc.nextInt();
		sc.close();
        int index = exponentialSearch(arr, key);

        if (index != -1) {
            System.out.println("The element is found at index = "+ index + " and position = "+(index+1));
        } else {
            System.out.println("The element is not found!");
        }
    }

    private static int exponentialSearch(int[] arr, int key) {
        int length = arr.length;
        if (arr[0] == key) {
            return 0;
        }

        int i = 1;
        while (i < length && arr[i] <= key) {
            i *= 2;
        }

        return binarySearch(arr, key, i / 2, Math.min(i, length - 1));
    }

    private static int binarySearch(int[] arr, int key, int low, int high) {
        while (low <= high) {
            int mid = low + (high - low) / 2;
            if (arr[mid] == key) {
                return mid;
            } else if (arr[mid] < key) {
                low = mid + 1;
            } else {
                high = mid - 1;
            }
        }
        return -1;
    }
}

