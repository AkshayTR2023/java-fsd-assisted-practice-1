package app4;

public class BubbleSortMain {
	public static void main(String[] args) {
	int[] arr = {1,324,342,5,2,123,4,-12};
	System.out.println("The predefined array is:");
	for(int x: arr) System.out.print(x+ " ");
	
	System.out.println("\nPerforming Bubble Sort...\nThe sorted array is:");
	bubbleSort(arr);
	for(int x: arr) System.out.print(x+ " ");
}
	public static void bubbleSort (int A[ ]) {
	     int n=A.length;       
	     for(int i=0; i<n-1;i++) {
	    	 for(int j=0;j<n-1-i;j++) {
	    		 if(A[j]>A[j+1])
	    			 A[j]=A[j]+A[j+1]-(A[j+1]=A[j]);
	    	 }
	     }
	}
}

