package app4;

public class SelectionSortMain {
	public static void main(String[] args) {
		int[] arr = {1,324,342,5,2,123,4,-12};
		System.out.println("The predefined array is:");
		for(int x: arr) System.out.print(x+ " ");
		
		System.out.println("\nPerforming Selection Sort...\nThe sorted array is:");
		selectionSort(arr);
		for(int x: arr) System.out.print(x+ " ");
	}
	public static void selectionSort (int A[ ]) {
         int n=A.length,minimum;        
         for(int i = 0; i < n-1 ; i++)  {
            minimum = i ;
            for(int j = i+1; j < n ; j++ ) {
                if(A[ j ] < A[ minimum ])  {                
                minimum = j ;
                }
             }
           A[minimum]=A[minimum]+A[i]-(A[i]=A[minimum]);
        }
   }

}
