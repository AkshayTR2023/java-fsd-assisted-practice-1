package app4;

import java.util.Scanner;

public class BinarySearchMain {
	public static void main(String[] args) {
		int[] arr= {-5,4,5,23,45,80,100,124};
		System.out.println("The predefined sorted array is: ");
		for(int x: arr) System.out.print(x+" ");
		System.out.println();
		Scanner sc = new Scanner(System.in);
		System.out.print("Enter the key to be found: ");
		int key =sc.nextInt();
		
		int f=0;
		int low=0, high=arr.length-1;
		int mid;
		while(low<=high) {
			mid=(low+high)/2;
			if(arr[mid]==key) {
				System.out.println("The element is found at index = "+ mid + " and position = "+(mid+1));
				f=1;
				break;
			}
			else if(arr[mid]<key) {
				low=mid+1;
				continue;
			}
			else {
				high=mid-1;
				continue;
			}
		}
		if(f==0) System.out.println("The element is not found!");
		sc.close();
	}
}

