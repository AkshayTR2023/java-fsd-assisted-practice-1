package app4;

import java.util.Scanner;

public class LinearSearchMain {
	public static void main(String[] args) {
		int[] arr = {1,324,342,5,2,123,4,-12};
		System.out.println("The predefined array is:");
		for(int x: arr) System.out.print(x+ " ");
		System.out.print("\nEnter the element to be found : ");
		Scanner sc= new Scanner(System.in);
		int key=sc.nextInt();
		sc.close();
		int i=0, flag=0;
		for(;i<arr.length;i++)
		{
			if(arr[i]==key) {
				flag=1;
				break;
			}
		}
		if(flag==1) {
			System.out.println("The element is found at index = "+ i + " and position = "+(i+1));
		}
		else System.out.println("The element is not found!");
	}
}
