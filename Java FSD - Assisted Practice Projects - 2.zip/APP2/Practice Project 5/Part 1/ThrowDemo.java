package kwdAndCustomExp;
import java.util.Scanner;

public class ThrowDemo {
	  public static void main(String[] args) {
		  Scanner sc = new Scanner(System.in);
		  System.out.print("Enter Age: ");
		  try {
			 
	      int age = getAge(sc.nextInt());
	      System.out.println("The age you've entered is: " + age);
	    } catch (IllegalArgumentException e) {
	      System.out.println("An error occurred: " + e.getMessage());
	    }
		  sc.close();
	  }

	  public static int getAge(int age) {
	    if (age < 0) {
	      throw new IllegalArgumentException("Age cannot be negative");
	    }
	    return age;
	  }
	}

