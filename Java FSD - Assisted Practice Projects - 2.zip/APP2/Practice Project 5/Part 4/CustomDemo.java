package kwdAndCustomExp;
import java.util.Scanner;

class InvalidAgeException extends Exception {
	private static final long serialVersionUID = 1L;

	public InvalidAgeException(String errorMessage) {
	    super(errorMessage);
	  }
	}

	public class CustomDemo {
	  public static void main(String[] args) {
		  Scanner sc = new Scanner(System.in);
		  System.out.print("Enter Age: ");
		  try {
			 
	      int age = sc.nextInt();
	      if (age < 0) {
	        extracted();
	        
	      }
	      else {
	          System.out.println("Age is: " + age);
	        }
	    } catch (InvalidAgeException e) {
	      System.out.println("An error occurred: " + e.getMessage());
	    }
		  sc.close();
		  
	  }

	private static void extracted() throws InvalidAgeException {
		throw new InvalidAgeException("Age cannot be negative");
	}
	}

