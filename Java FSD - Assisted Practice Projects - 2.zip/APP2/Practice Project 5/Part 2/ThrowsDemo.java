package kwdAndCustomExp;

import java.util.Scanner;

public class ThrowsDemo {
  public static void main(String[] args) {
	  Scanner sc=new Scanner(System.in);
	  System.out.println("Enter 2 numbers: ");
	  try {
    	
      int result = divide(sc.nextInt(),sc.nextInt());
      System.out.println("Integer Division of the numbers: " + result);
    } catch (ArithmeticException e) {
      System.out.println("An error occurred: " + e.getMessage());
    }
	  sc.close();
  }

  public static int divide(int a, int b) throws ArithmeticException {
    if (b == 0) {
      throw new ArithmeticException("Cannot divide by zero");
    }
    return a / b;
  }
}

