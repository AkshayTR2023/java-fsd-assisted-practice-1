package kwdAndCustomExp;

import java.util.Scanner;

public class FinallyDemo {
	  public static void main(String[] args) {
		  Scanner sc=new Scanner(System.in);
		  System.out.println("Enter 2 numbers: ");
		  try {
	    	
	      int result = divide(sc.nextInt(),sc.nextInt());
	      System.out.println("Result: " + result);
	    } catch (ArithmeticException e) {
	      System.out.println("An error occurred: " + e.getMessage());
	    } finally {
	      System.out.println("Finally block executed");
	    }
		  sc.close();
	  }

	  public static int divide(int a, int b) {
	    try {
	      return a / b;
	    } catch (ArithmeticException e) {
	      throw e;
	    } finally {
	      System.out.println("Finally block of divide executed");
	    }
	  }
	}
