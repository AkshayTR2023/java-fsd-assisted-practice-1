package tryCatchDemo;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class TryCatchDemo {
  public static void main(String[] args) {
    BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
    try {
      System.out.print("Enter a number: ");
      int num = Integer.parseInt(reader.readLine());
      int result = 100 / num;
      System.out.println("Result: " + result);
    } catch (NumberFormatException e) {
      System.out.println("Invalid input. Please enter a number.");
    } catch (ArithmeticException e) {
      System.out.println("Cannot divide by zero.");
    } catch (IOException e) {
      System.out.println("An error occurred while reading input.");
    } finally {
      try {
        reader.close();
      } catch (IOException e) {
        System.out.println("An error occurred while closing the reader.");
      }
    }
  }
}
