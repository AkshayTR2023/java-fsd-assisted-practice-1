/************************************SOURCE CODE*********************************/
/***********************************FILE HANDLER**********************************/
/****************************java file name = fileHandlerMain.java**********************/
package filehandling;
import java.io.*;
import java.util.Scanner;
// Class containing methods to perform operations
class fileOper{
	// File Reader
	public static void readFile(File file) {
        try (BufferedReader reader = new BufferedReader(new FileReader(file))) {
            System.out.println("Reading file ...");
            String line;
            while ((line = reader.readLine()) != null) {
                System.out.println(line);
            }
        } catch (IOException e) {
            System.out.println("An error occurred while reading the file: " + e.getMessage());
        }
    }
	//File Writer
    public static void writeFile(File file, Scanner scanner) {
        System.out.print("Enter the text you want to write: ");
        String text = scanner.nextLine();
        writeToFile(file, text, false);
        System.out.println("Writing to file ...");
    }
    //File Appender
    public static void appendFile(File file, Scanner scanner) {
        System.out.print("Enter the text you want to append: ");
        String text = scanner.nextLine();
        writeToFile(file, text, true);
        System.out.println("Appending to file ...");
    }
    //writeToFile method definition
    public static void writeToFile(File file, String text, boolean append) {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(file, append))) {
            writer.write(text);
        } catch (IOException e) {
            System.out.println("An error occurred while writing to the file: " + e.getMessage());
        }
    }
}
//class containing main method
public class fileHandlerMain {

    public static void main(String[] args) {

        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter the file name: ");
        String fileName = scanner.nextLine();

        File file = new File(fileName);

        if (!file.exists()) {
            System.out.println("The file does not exist. Creating a new file...");
        }

        try {
            while (true) {
            	//Getting choice from the user...
                System.out.print("Enter the operation you want to perform (R = Read, W = Write, A = Append): ");
                String operation = scanner.nextLine();
               
                switch (operation.toUpperCase()) {
                    case "R":
                        fileOper.readFile(file);
                        break;
                    case "W":
                    	fileOper.writeFile(file, scanner);
                        break;
                    case "A":
                    	fileOper.appendFile(file, scanner);
                        break;
                    default:
                    	System.out.println("Invalid operation. Please try again.");
                        break;
                }
                //Checking if the user wants to perform more operations on the file
                System.out.print("Do you want to perform another operation on the same file? (y/n): ");
                String choice = scanner.nextLine();

                if (choice.equalsIgnoreCase("n")) {
                    break;
                }
            }
        } finally {
            scanner.close();
            System.out.println("Program terminated successfully!");
        }
    }

}


