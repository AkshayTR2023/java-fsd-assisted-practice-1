package sleepwaitDemo;

public class SleepAndWaitDemo {
    public static void main(String[] args) {
        Runnable task = () -> {
            synchronized (SleepAndWaitDemo.class) {
                try {
                    System.out.println(Thread.currentThread().getName() + " is sleeping...");
                    Thread.sleep(2000);
                    System.out.println(Thread.currentThread().getName() + " has woken up.");
                    SleepAndWaitDemo.class.notify();
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
        };

        Thread thread1 = new Thread(task, "Thread 1");
        Thread thread2 = new Thread(() -> {
            synchronized (SleepAndWaitDemo.class) {
                try {
                    System.out.println(Thread.currentThread().getName() + " is waiting...");
                    SleepAndWaitDemo.class.wait();
                    System.out.println(Thread.currentThread().getName() + " has been notified.");
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
        }, "Thread 2");

        thread1.start();
        thread2.start();
    }
}
