package threads;

public class runnableMain implements Runnable {
    
    private int count;
    
    public runnableMain(int count) {
        this.count = count;
    }
    
    public void run() {
        System.out.println("Starting thread " + Thread.currentThread().getName());
        for (int i = 1; i <= count; i++) {
            System.out.println("Thread " + Thread.currentThread().getName() + " count: " + i);
        }
        System.out.println("Finishing thread " + Thread.currentThread().getName());
    }
    
    public static void main(String[] args) {
        runnableMain myRunnable1 = new runnableMain(5);
        runnableMain myRunnable2 = new runnableMain(10);
        
        Thread thread1 = new Thread(myRunnable1);
        Thread thread2 = new Thread(myRunnable2);
        
        thread1.start();
        thread2.start();
    }
}
