package threads;

public class threadImplementation extends Thread {
    
    private int count;
    
    public threadImplementation(int count) {
        this.count = count;
    }
    
    public void run() {
        System.out.println("Starting thread " + Thread.currentThread().getName());
        for (int i = 1; i <= count; i++) {
            System.out.println("Thread " + Thread.currentThread().getName() + " count: " + i);
        }
        System.out.println("Finishing thread " + Thread.currentThread().getName());
    }
    
    public static void main(String[] args) {
    	threadImplementation thread1 = new threadImplementation(5);
    	threadImplementation thread2 = new threadImplementation(10);
        
        thread1.start();
        thread2.start();
    }
}
